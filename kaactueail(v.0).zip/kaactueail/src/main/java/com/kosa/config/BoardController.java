package com.kosa.config;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kosa.dao.BoardDAO;
import com.kosa.model.BoardDTO;

@WebServlet("/board.do")
public class BoardController extends HttpServlet{
	public BoardController() {}
	
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String cmd = request.getParameter("cmd");	// *~~?cmd=list
		
		request.setCharacterEncoding("UTF-8");
		
		
		if(cmd.equals("list")) {
			list(request, response);
		}/*else if(cmd.equals("write")) {
			write(request, response);
		}*/
	}	//service end
	
	
	public void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		BoardDAO dao = new BoardDAO();
		List<BoardDTO> list = dao.selectAll();
		
		if(list != null) {
			request.setAttribute("list", list); // data save
			request.getRequestDispatcher("views/list.jsp").forward(request, response);
		}else {
			response.sendRedirect("/views/error.jsp");
		}
	}
}
